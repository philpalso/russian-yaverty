Welcome to a new version of Russian ЯВЕРТЫ

A Windows keyboard layout for typing Russian using a phonetic (homophonic) mapping, where each Latin key maps to the Cyrillic letter it sounds like (z → з, w → в, i → и, …).

It is built on top of the Swedish physical keyboard layout, so key positions, punctuation, and AltGr characters line up with a Swedish keyboard.

Layout See the attached mapping images (/_LayoutPics) for more information. The mapping is homophonic — Latin key → phonetically similar Cyrillic letter.

Installation

Option A — Installer (easiest)

Download the latest release and unzip it. Run setup.exe. Add the keyboard under Settings → Time & language → Language & region → Russian → ⋯ → Language options → Add a keyboard, then select this layout.

To remove the built-in Russian — Mnemonic keyboard so it doesn't clutter your input switcher, remove it from the same Language options screen.

Notes & known limitations

Designed for a Swedish physical keyboard. On other physical layouts the letters still type correctly, but the legends printed on non-letter keys may not match.

License

MIT — see LICENSE. Built from scratch with Microsoft Keyboard Layout Creator 1.4 (no third-party layout used as a base).
(c) 2026 PhilPalso

Credits

Mapping mirrors the ChromeOS / Linux ru(phonetic) phonetic layout. Built with Microsoft Keyboard Layout Creator 1.4.